//
// Created by Meep on 11/18/2022.
//

#include <iostream>
#include <list>
using namespace std;

void isBomb(list<int> l,int position){
    auto it=l.begin();
    while(position--){
        it++;
    }
    if(it.)
}

int main(){
    int n,k,v,ball;
    cin>>n>>k>>v;
    list<int> game;
    while(n--){
        cin>>ball;
        game.push_back(ball);
    }

}