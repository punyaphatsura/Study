#include <iostream>
#include <vector>

int count(int f,node* n){
    if(f>0){
        if(n->right==NULL && n->left==NULL)return 0;
        if(n->left==NULL) return count(--f,n->right);
        if(n->right==NULL) return count(--f,n->left);
    }else return 1;
    return count(--f,n->left)+count(--f,n->right);
}

int count(node* n,int count,std::vector<std::vector<int>> &v){
    if(v.size()-1<n){
        std::
        v.push_back()
    }
}



std::vector<std::vector<int>> level_order(){
    std::vector<std::vector<int>> result;
    int n=0;
    count(mRoot,n,result);
    return result;
}

int main(){

}