//
// Created by Meep on 9/6/2022.
//
#include <iostream>
#include <map>
#include <set>

using namespace std;

int main(){
    map<string,int> wordcount;
    set<string> sameword;
    int n;
    string word;
    cin>>n;
    while(n--){
        cin>>word;
        if (wordcount.find(word)!=wordcount.end()){
            wordcount[word]++;
            sameword.insert(word);
        }else{
            wordcount[word] = 1;
        }
    }

    for(auto w:sameword){
        cout<<w<<" "<<wordcount[w]<<"\n";
    }
}
