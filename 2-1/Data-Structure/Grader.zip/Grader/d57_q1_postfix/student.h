#ifndef __STUDENT_H__
#define __STUDENT_H__
#include <vector>
#include <stack>

using namespace std;

int eval_postfix(vector<pair<int,int>> v){
    stack <int> pos,operation;
    int a,b;
    for (int i;i<v.size();i++){
        if (v[i].first>0){
            pos.push(v[i].second);
        }else{
            a = pos.top();pos.pop();
            b = pos.top();pos.pop();
            if(v[i].second==0){
                pos.push(b+a);
            }else if(v[i].second==1){
                pos.push(b-a);
            }else if(v[i].second==2){
                pos.push(b*a);
            }else if(v[i].second==3){
                pos.push(b/a);
            }
        }

    }
    return pos.top();
}

#endif
