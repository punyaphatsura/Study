void shift(int k) {
	// TODO: Add your code here
    while(k<0){
        k+=mSize;
    }
    int times=k%mSize;


    while(times) {
        auto it=begin();

        mHeader->next=mHeader->next->next;
        mHeader->next->prev=mHeader;

        mHeader->prev->next=it.ptr;
        it.ptr->prev=mHeader->prev;

        it.ptr->next=mHeader;
        mHeader->prev=it.ptr;

        times--;
    }
}
