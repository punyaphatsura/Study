//
// Created by Meep on 9/2/2022.
//
#include <iomanip>
#include <iostream>
#include <map>

using namespace std;

int main(){
    cout << std::fixed << std::setprecision(2);
    int n,score;
    string num,teacher;
    map<string,float> allNum,allTeacher,countNum,countTeacher;
    cin>>n;
    while(n--){
        cin>>num>>teacher>>score;
        if (allNum.find(num)==allNum.end()){
            allNum[num] = score;
            countNum[num] = 1;

        }else{
            allNum[num] = allNum[num]+score;
            countNum[num]++;
        }
        if (allTeacher.find(teacher)==allTeacher.end()){
            allTeacher[teacher] = score;
            countTeacher[teacher] = 1;
        }else{
            allTeacher[teacher] =allTeacher[teacher] + score;
            countTeacher[teacher]++;
        }
    }

//    for (auto &x:allNum){
//        cout<<x.first<<" "<<x.second<<endl;
//    }
//    cout<<"--------------------------"<<endl;
//    for (auto &x:countNum){
//        cout<<x.first<<" "<<x.second<<endl;
//    }
//    cout<<"--------------------------"<<endl;
//    for (auto &x:allTeacher){
//        cout<<x.first<<" "<<x.second<<endl;
//    }
//    cout<<"--------------------------"<<endl;
//    for (auto &x:countTeacher){
//        cout<<x.first<<" "<<x.second<<endl;
//    }
//    cout<<"--------------------------"<<endl;


    for (auto it = allNum.begin();it!=allNum.end();it++){
        cout<<it->first<<" "<<(it->second+0.0)/countNum[it->first]<<endl;
    }

    for (auto it2 = allTeacher.begin();it2!=allTeacher.end();it2++){
//        cout<<((it2->second)+0.0)<<"/"<<(countTeacher[it2->first])<<endl;
        cout<<it2->first<<" "<<((it2->second)+0.0)/(countTeacher[it2->first])<<endl;
    }
}