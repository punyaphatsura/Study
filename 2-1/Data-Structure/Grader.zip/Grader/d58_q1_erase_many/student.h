#ifndef __STUDENT_H_
#define __STUDENT_H_


template <typename T>
void CP::vector<T>::erase_many(const std::vector<int> &pos) {
  //write your code here
  int p = 1;
  int count = 1;
  for (int i = pos[0]+1;i<mSize;i++){
      if (i==pos[p]&&p<pos.size()){
          p++;
          count++;
      }else{
          mData[i-count]=mData[i];
      }
  }
  mSize = mSize-count;
}

#endif
