void replace(const T& x, list<T>& y) {
  //write your code here
  auto it=begin();
  while(it!=end()){
      if(it.ptr->data==x){
          auto str=y.begin();
          while(str!=y.end()){
              insert(it,str.ptr->data);
              str++;
          }

          it = erase(it);
          it--;
      }
      it++;
  }

}
