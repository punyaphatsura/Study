#ifndef __STUDENT_H_
#define __STUDENT_H_


template <typename T>
void CP::stack<T>::multi_pop(size_t K) {
  //write your code here
  int count;
  if (K<size()) count=K;
  else count = size();
  while(count--){
      pop();
  }
}

template <typename T>
std::stack<T> CP::stack<T>::remove_top(size_t K) {
  //write your code here
  //
  //don't forget to return an std::stack
  std::stack<T> st;
  std::stack<T> out;
  int count;
  if (K<size()) count=K;
  else count = size();
  while(count--){
      st.push(top());
      pop();
  }

  while(st.size()){
      out.push(st.top());
      st.pop();
  }

  return out;
}

#endif
