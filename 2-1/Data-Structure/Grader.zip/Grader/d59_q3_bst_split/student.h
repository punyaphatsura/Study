#ifndef __STUDENT_H_
#define __STUDENT_H_

template <typename KeyT,
          typename MappedT,
          typename CompareT >
CP::map_bst<KeyT,MappedT,CompareT> CP::map_bst<KeyT,MappedT,CompareT>::split(KeyT val) {
  //your code here
  CP::map_bst<KeyT,MappedT,CompareT> result;
  auto it=begin();
  while(it!=end()){
      if(it->first>=val){
          result.insert(it->first);
          it = erase(it);
      }
      else it++;
  }
  return result;
}

#endif
