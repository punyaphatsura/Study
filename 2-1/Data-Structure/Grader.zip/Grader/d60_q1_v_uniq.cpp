#include <iostream>
#include <vector>
#include <set>

using namespace std;

int main(){
    int n,x;
    cin>>n;
    set<int> s;
    vector<int> v;

    while(n--){
        cin>>x;
        if (s.find(x)==s.end()){
            v.push_back(x);
            s.insert(x);
        }

    }
    cout<<"Result\n";
    for (auto i:v){
        cout<<i<<" ";
    }

}