#include "stack.h"
#include "queue.h"

namespace CP {
    template<typename T>
    void stack<T>::appendStack(stack<T> s) {
        stack<T> b;
        while(!empty()){
            b.push(top());
            pop();
        }
        while(!s.empty()){
            b.push(s.top());
            s.pop();
        }
        while(!b.empty()){
            push(b.top());
            b.pop();
        }
    }

    template<typename T>
    void stack<T>::appendQueue(queue<T> q) {
        stack<T> b;
        while(!empty()){
            b.push(top());
            pop();
        }
        while(!q.empty()){
            b.push(q.front());
            q.pop();
        }
        while(!b.empty()){
            push(b.top());
            b.pop();
        }
    }

    template<typename T>
    void queue<T>::appendStack(stack<T> s) {
        while(!s.empty()){
            push(s.top());
            s.pop();
        }
    }

    template<typename T>
    void queue<T>::appendQueue(queue<T> q) {
        while(!q.empty()){
            push(q.front());
            q.pop();
        }
    }
}
