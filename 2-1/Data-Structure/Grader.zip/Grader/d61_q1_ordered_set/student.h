#include <vector>
#include <algorithm>
#include <set>

using namespace std;

template <typename T>
vector<T> Union(const vector<T>& A, const vector<T>& B) {
    vector<T> v;
    set<T> s(A.begin(),A.end());
    if (A.size()==0)return B;
    if (B.size()==0)return A;
    v = A;
    for (int i=0;i<B.size();i++){
        if (find(A.begin(),A.end(),B[i])==A.end()){
            v.push_back(B[i]);
        }
    }
    return v;
}

template <typename T>
vector<T> Intersect(const vector<T>& A, const vector<T>& B) {
    vector<T> v;

    if (A.size()==0 || B.size()==0)return v;
    for (int i=0;i<A.size();i++){
        if (find(B.begin(),B.end(),A[i])!=B.end()){
            v.push_back(A[i]);
        }
    }

    return v;
}
