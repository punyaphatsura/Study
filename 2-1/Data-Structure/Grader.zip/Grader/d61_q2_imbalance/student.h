// Your code here


int answer(node* n,KeyT ans,int mx){
    if(n==NULL)return -1;
    int lh=answer(n->left,ans,mx);
    int rh=answer(n->right,ans,mx);
    int ib=lh-rh;
    ib=(ib>0? ib:-ib);
    if(ib>mx){
        mx=ib;
        ans=n->data.first;
    }
    else if(ib==mx && n->data.first<ans)ans=n->data.first;
    return 1+(lh>rh?lh:rh);

}

KeyT getValueOfMostImbalanceNode() {
    // Your code here
    int mx=0;
    KeyT ans=mRoot->data.first;
    answer(mRoot,ans,mx);
    return ans;
}
