void splitList(list<T>& list1, list<T>& list2) {
    // Add your code here
    int a,b,count;
    count=0;
    b=mSize/2;
    a=mSize-b;
    list1.mSize=a+list1.size();
    list2.mSize=b+list2.size();
    auto tmp1=begin();
    for(size_t i=0;i<a;i++)tmp1++;
    list1.mHeader->prev->next=mHeader->next;
    mHeader->next->prev=list1.mHeader->prev;
    list1.mHeader->prev=tmp1.ptr->prev;
    tmp1.ptr->prev->next=list1.mHeader;

    list2.mHeader->prev->next=tmp1.ptr;
    tmp1.ptr->prev=list2.mHeader->prev;
    list2.mHeader->prev=mHeader->prev;
    mHeader->prev->next=list2.mHeader;

    mHeader->next=mHeader;
    mHeader->prev=mHeader;
    mSize=0;
}
