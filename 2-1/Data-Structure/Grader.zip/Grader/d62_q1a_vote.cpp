//
// Created by Meep on 9/1/2022.
//
#include <iostream>
#include <map>

using namespace std;

int main(){
    int n,k;
    string vote;
    map <string,int> count,sorted_count;
    cin>>n>>k;
    while(n--){
        cin>>vote;
        if (count.find(vote)!=count.end()){
            count[vote]++;

        }
        else{
            count[vote]=1;
        }
    }

    for (auto &x:count){
        sorted_count[to_string(x.second)+x.first]=x.second;
    }

//    for (auto &x:sorted_count){
//        cout<<x.first<<" "<<x.second<<endl;
//    }

    auto it = sorted_count.end();

    if (k>sorted_count.size()){
        cout<<sorted_count.begin()->second;
    }
    else
    {
        while (k--) {
            it--;
        }
        cout << it->second;
    }
}