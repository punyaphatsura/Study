//
// Created by Meep on 8/31/2022.
//
#include <iostream>
#include <map>

using namespace std;

int main(){
    ios_base::sync_with_stdio(false); cin.tie(0);
    int m,n;
    long long father,son,s1,s2;
    map<int,int> son2fath;
    cin>>m>>n;
    while(m--){
        cin>>father>>son;
        if(son2fath.find(son)==son2fath.end())son2fath[son]=father;
    }
//    cout<<son2fath.size()<<endl;

//    for (auto it = son2fath.begin();it!=son2fath.end();it++){
//        cout<<"S:"<<it->first<<" F:"<<it->second<<endl;
//    }

    while(n--){
        cin>>s1>>s2;
        if (s1!=s2&&
        son2fath.find(s1)!=son2fath.end()&&
        son2fath.find(s2)!=son2fath.end()&&
        son2fath.find(son2fath[s1])!=son2fath.end()&&
        son2fath.find(son2fath[s2])!=son2fath.end()&&
        son2fath[son2fath[s1]]==son2fath[son2fath[s2]])
        {
//            cout<<"Father of "<<s1<<" is "<<son2fath[s1]<<" Father of "<<s2<<" is "<<son2fath[s2];
//            cout<<endl<<"s1's grandpa:"<<son2fath[son2fath[s1]]<<" s2's grandpa:"<<son2fath[son2fath[s2]]<<endl;
            cout<<"YES"<<endl;

        }
        else{
            cout<<"NO"<<endl;
        }
    }
}
