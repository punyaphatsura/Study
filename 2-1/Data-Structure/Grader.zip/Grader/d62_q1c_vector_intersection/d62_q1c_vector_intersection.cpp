//
// Created by Meep on 8/31/2022.
//
#include <iostream>
#include <set>

using namespace std;

int main(){
    int n,m,o;
    set<int> s,out;
    cin>>m>>n;

    while(m--){
        cin>>o;
        s.insert(o);
    }

    while(n--){
        cin>>o;
        if (s.find(o)!=s.end()){
            out.insert(o);
        }
    }

    for (auto&x:out){
        cout<<x<<" ";
    }
}