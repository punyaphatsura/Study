#include <iostream>

using namespace std;

int main(){
    int p;
    int i = 1;
    cin>>p;
    while(p>=i)i*=2;
    cout<<i-p;
    return 0;
}