#ifndef __STUDENT_H_
#define __STUDENT_H_

#include <algorithm>

template <typename T>
void CP::list<T>::shift_left() {
  // your code here
  auto tmp=mHeader->next;
  tmp->next->prev=mHeader;
  tmp->prev=mHeader->prev;
  mHeader->next=tmp->next;
  mHeader->prev->next=tmp;
  tmp->next=mHeader;
  mHeader->prev=tmp;
}

#endif
