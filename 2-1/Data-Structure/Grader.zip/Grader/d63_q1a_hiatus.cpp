//
// Created by Meep on 9/3/2022.
//
#include <iostream>
#include <set>

using namespace std;

int main(){
    std::ios_base::sync_with_stdio(false); std::cin.tie(0);
    int n,m,y,mon,x1,x2;
    set<pair<int,int>> s;
    auto it = s.begin();
    cin>>n>>m;
    while(n--){
        cin>>y>>mon;
        s.insert(make_pair(y,mon));
    }

    while(m--){
        cin>>x1>>x2;
        auto p = make_pair(x1,x2);
        it = s.lower_bound(p);
        if (it==s.begin()&&*it!=p){cout<<"-1 -1 ";}
        else if(*it==p){cout<<"0 0 ";}
        else {it--; cout<<it->first<<" "<<it->second<<" "; }
    }
}