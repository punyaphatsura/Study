//
// Created by Meep on 9/3/2022.
//
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main(){
    std::ios_base::sync_with_stdio(false); std::cin.tie(0);
    int n,m,k,x,p;
    vector<int> v;
    cin>>n>>m>>k;
    while(n--){
        cin>>x;
        v.push_back(x);
    }

    sort(v.begin(),v.end());

    cout<<endl;

    while(m--){
        cin>>p;
//        cout<<"Range is ["<<p-k<<","<<p+k<<"]"<<endl;
        cout<<upper_bound(v.begin(),v.end(),p+k)-lower_bound(v.begin(),v.end(),p-k)<<" ";
    }
}