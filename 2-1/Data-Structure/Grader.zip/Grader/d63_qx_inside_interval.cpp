//
// Created by Meep on 9/3/2022.
//
#include <iostream>
#include <map>
#include <algorithm>

using namespace std;

int main(){
    std::ios_base::sync_with_stdio(false); std::cin.tie(0);
    int n,m,x1,x2,x;
    map<int,int> allNum;
    bool isNotInRange;
    cin>>n>>m;
    while(n--){
        cin>>x1>>x2;
        allNum[x2] = x1;
    }

//    for (auto &u:allNum){
//        cout<<u<<" ";
//    }
//
//    cout<<endl;

//    for (auto it = allNum.begin();it!=allNum.end();it++){
//        cout<<it->first<<" "<<it->second<<endl;
//    }

    while(m--){
        isNotInRange = true;
        cin>>x;
        if(x>=allNum.lower_bound(x)->second&&x<=allNum.lower_bound(x)->first){
            cout<<"1 ";
        }
        else{
            cout<<"0 ";
        }

    }
}