//
// Created by Meep on 9/6/2022.
//
#include <iostream>
#include <vector>
#include <algorithm>
#include <map>

using namespace std;

int main(){
    int n,m,x,y,amount, round;
    int i = 1;
    bool isLose = false;
    vector<int> oppCard;
    map<int,int> myCard;
    cin>>n>>m;

    while(n--){
        cin>>x;
        if (myCard.find(x)!=myCard.end()){
            myCard[x]++;
        }else{
            myCard[x] = 1;
        }
//        cout<<n<<"\n";
    }
//    cout<<"My Card: ";
//    for (auto &z:myCard){
//        cout<<z<<" ";
//    }
//    cout<<"\n";

    auto q = myCard.begin();

    while(i<=m){
//        cout<<i<<"\n";
        cin>>amount;
        oppCard = {};
        while(amount--){
            cin>>y;
            oppCard.push_back(y);
        }
//        for (auto &u:oppCard){
//            cout<<u<<" ";
//        }
//        cout<<"\n";

        if (!isLose && myCard.size()>0){
            for (auto c:oppCard){
                q = myCard.upper_bound(c);
//                cout<<(q<myCard.end());
//                cout<<"\nq is pointing at "<<q->first<<" with "<<q->second<<" card "<<" compare with "<<c<<"\n";
                if (q!=myCard.end() && q->second>0){
//                    cout<<"Yeah Im win\n";
                    q->second--;
                    if (q->second==0){
                        myCard.erase(q);
                    }
                }else{
//                    cout<<"Im losed\n";
                    isLose = true;
                    round = i;
                    break;

                }
            }
        }
        i++;
    }
    if (isLose){cout<<round;}
    else{cout<<i;}
}