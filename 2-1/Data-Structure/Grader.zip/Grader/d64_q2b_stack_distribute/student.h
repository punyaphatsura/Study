#ifndef __STUDENT_H__
#define __STUDENT_H__

#include <vector>
template <typename T>
std::vector<std::vector<T>> CP::stack<T>::distribute(size_t k) const {
  //write your code here
  std::vector<std::vector<T>> out(k);
  T *data = mData;
  int s = mSize;
  if (size()%k==0){
      for(int j=0;j<k;j++){
          for(int i=0;i<size()/k;i++){
              out[j].push_back(data[s-1]);
              s--;
          }
      }
  }else{
      int l = size()%k;
      for(int j=0;j<k;j++){
          if (j<l){
              for(int i=0;i<size()/k+1;i++){
                  out[j].push_back(data[s-1]);
                  s--;
              }
          }else{
              for(int i=0;i<size()/k;i++){
                  out[j].push_back(data[s-1]);
                  s--;}
              }
          }
      }
  return out;
}
#endif
