#ifndef __STUDENT_H_
#define __STUDENT_H_

#include <algorithm>
template <typename T>
void CP::vector<T>::rotate(iterator first, iterator last, size_t k) {
  //write your code here
  if (k == 0) return;
  if (last>first)return;
  if (first<begin() || last>=end())return;
  int len = k%(last-first);
  T *v = new T();
  for (int i=0;i<len;i++){
      v[i] = mData[i+first-begin()];
  }
  for (int j=0;j<last-begin()-len;j++){
      mData[first+j-begin()]=mData[first-begin()+j+len];
  }
  for (int l=0;l<len;l++){
      mData[last-begin()-len+l] = v[l];
  }

    std::rotate(first,first+len,last);

  delete v;

}

#endif
