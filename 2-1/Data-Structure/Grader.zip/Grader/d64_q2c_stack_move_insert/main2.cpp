#include <iostream>
#include <vector>
#include "stack.h"
#include "student.h"
using namespace std;

int main(){
    CP::stack<int> a;
    CP::stack<int> b;

    a.push(2);
    a.push(2);
    a.push(3);


    cout<<(b<a);

//    a.push()



}