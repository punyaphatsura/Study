#ifndef __STUDENT_H__
#define __STUDENT_H__

#include <queue>
#include <stack>
#include "stack.h"

template <typename T>
void CP::stack<T>::moveInsert(int k,CP::stack<T> &s2, int m) {
  //your code here
  std::stack<T> q1,q2;
  int count;
  if (m<s2.size())count=m;
  else count=s2.size();
  while(count--){
      q1.push(s2.top());
      s2.pop();
  }

  while(k){
      q2.push(top());
      pop();
      k--;
  }

    while (!q1.empty()){
        push(q1.top());
        q1.pop();
    }

    while (!q2.empty()){
        push(q2.top());
        q2.pop();
    }

}

template<typename T>
bool CP::stack<T>::operator<(const CP::stack<T> &s2) {
    stack<T> b = stack(s2);
    if (b.size()>mSize)return true;
    else if (b.size()<mSize)return false;
    else{
        for(int i=mSize-1;i>=0;i--){
            if(mData[i]<b.top())return true;
            if(mData[i]>b.top())return false;
            b.pop();
        }
    }return false;

void CP::stack<T>::removeAt(int k,int m) {
    stack<T> b = stack(s2);
    if (b.size()>mSize)return true;
    else if (b.size()<mSize)return false;
    else{
        for(int i=mSize-1;i>=0;i--){
            if(mData[i]<b.top())return true;
            if(mData[i]>b.top())return false;
            b.pop();
        }

        T *v = new T[]();
    }return false;

}

#endif
