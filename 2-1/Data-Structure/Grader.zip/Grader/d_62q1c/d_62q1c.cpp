#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main(){
    string t;
    int x;
    vector<int> v;
    int n;
    cin>>n;
    while(n>0){
        n--;
        cin>>t;
        if (t=="pb"){
            cin>>x;
            v.push_back(x);
        }
        else if (t=="sa"){
            sort(v.begin(),v.end());
        }
        else if (t=="sd"){
            sort(v.begin(),v.end());
            reverse(v.begin(),v.end());
        }
        else if (t=="r"){
            reverse(v.begin(),v.end());
        }
        else{
            cin>>x;
            v.erase(v.begin()+x);
        }

    }
    for (int i = 0; i<v.size();i++){
        cout<<v[i]<<" ";
    }
};