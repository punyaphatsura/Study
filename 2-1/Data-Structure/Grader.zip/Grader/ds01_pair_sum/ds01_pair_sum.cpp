#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
using namespace std;


int main() {
    int n,t,x,c;
    cin>>n>>t;
    map<int,int> m;
    while(n>0){
        n--;;
        cin>>x;
        if (m.find(x) != m.end()){
            m[x]++;
        }else{
            m[x] = 1;
        }
    }
//    for (auto &x:m){
//        cout<<x.first<<","<<x.second<<endl;
//    }

    while(t>0) {
        cin>>c;
        t--;
        bool found = false;
        for (auto &i:m){
            if (i.first>=c/2+1){
                continue;
            }
            if ((m.find(c-i.first)!=m.end())){
                if (((i.first==c-i.first) && (i.second==1))){
                    continue;
                }
//                cout<<"FOUND!!"<<i.first<<i.second<<" with "<<c-i.first;
                found = true;
                break;
            }
        }
        if (found){
            cout<<"YES\n";
        }else{
            cout<<"NO\n";
        }
    }
    return 0;
}