//
// Created by Meep on 8/29/2022.
//
#include <iostream>
#include <map>
#include <algorithm>

using namespace std;

int main(){
    map<string,int> count;
    int n;
    int most = 0;
    string mw;
    string word;
    cin>>n;
    while(n--){
        cin>>word;
        if (count.find(word)!=count.end()) {
            count[word]++;
        }else{
            count[word] = 1;
        }
    }
    for (auto &x:count){
        if (x.second>=most){
            most = x.second;
            mw = x.first;
        }
    }
    cout<<mw<<" "<<most;
}