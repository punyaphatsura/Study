#include <iostream>


int main()
{
    int H;
    int M;
    int x;
    std::cin>>H>>M;
    std::cin>>x;
    M = M+x;
    if (M+x>=60){
        H = H + (M - (M%60))/60;
        M = M%60;

    }
    if (H>=24){
        H = H%24;
    }
    if (H<10&&M<10){
        std::cout<<'0'<<H<<' '<<'0'<<M;
    }
    else if (H>10&&M<10){
        std::cout<<H<<' '<<'0'<<M;
    }
    else if (H<10&&M>10){
        std::cout<<'0'<<H<<' '<<M;
    }
    else{
        std::cout<<H<<' '<<M;
    }
    return 0;
}
