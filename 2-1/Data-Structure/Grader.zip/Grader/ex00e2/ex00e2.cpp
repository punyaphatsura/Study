#include <iostream>
#include <vector>

using namespace std;

int main() {
    int n;
    int m;
    int r;

    cin >> n >> m;
    cin >> r;
    vector<int> v;
    for (int i = 0;i<n;i++){
        for (int j = 0; j<m; j++){
            int p;
            cin >> p;
            v.push_back(p);
        }
    }

//    for (int i = 0;i<n;i++){
//        for (int j=0; j<m; j++){
//            cout << v[i*m+j] << ' ';
//        }
//        cout << endl;
//    }

    int r1;
    int c1;
    int r2;
    int c2;
    int compare;

    for (int i = 0 ; i < r ; i++){

        cin >> r1 >> c1 >> r2 >> c2;
        if (r1<=r2 && c1<=c2 && r1<=n && c1<=m) {
            compare = v[(r1 - 1) * m + (c1 - 1)];
            for (int j = r1 - 1; j < r2 && j<=n ; j++) {
                for (int k = c1 - 1; k < c2 && k<=m ; k++) {
//                    if (j == r1 - 1 && k == c1 - 1) {
//                        cout << "First compare is : " << compare << endl;
//                    }
//                    cout << v[j * m + k] << ' ';
                    if (compare < v[j * m + k]) {compare = v[j * m + k];}
                }
//                cout << endl;

            }
            cout << compare << endl;
            //cout << 2 << endl;
        }
        else if (r1>r2 or c1>c2){cout << "INVALID" << endl;}
        else {cout << "OUTSIDE" << endl;}
    }

    return 0;
}
