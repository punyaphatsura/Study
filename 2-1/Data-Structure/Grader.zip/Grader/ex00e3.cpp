//
// Created by Meep on 9/3/2022.
//
#include <iostream>
#include <set>

using namespace std;

int main(){
    int n,x;
    cin>>n;
    int i = n;
    set<int> s;
    while(n--){
        cin>>x;
        if (x>0){
            s.insert(x);
        }
        else{
            s.insert(0);
            break;
        }
    }

//    for (auto p = s.begin();p!=s.end();p++){
//        cout<<*p<<" ";
//    }
    auto q = s.end();
    q--;
//    cout<<"\n"<<s.size()<<" "<<*q<<" "<<i<<"\n";

    if (s.size()!=i || *q!=i){
        cout<<"NO";
    }else{
        cout<<"YES";
    }
}