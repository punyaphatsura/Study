#include <iostream>
#include <bits/stdc++.h>

#define VVI vector<vector<int>>


using namespace std;

int main(){
    int n,s;
    int mn_price = 0;
    int cr = 0;
    cin >> n >> s;
    VVI catalog(s);
    vector<int> have(n+1), cost(s);
    for(int i = 0;i<=n;i++)have[i] = 0;
    for(int i = 0;i<s;i++){
        int c,num;
        cin >> c >> num;
        cost[i] = c;
        mn_price = mn_price + c;
        while(num){
            num--;
            int book;
            cin >> book;
            cr++;
            catalog[i].push_back(book);
        }
    }
    priority_queue< pair< pair<int,vector<int>>, pair<int, pair<int,int> > > > pq;
    pq.push(make_pair(make_pair(0,have), make_pair(0,make_pair(n,cr))));
    while(!pq.empty()){
        auto node = pq.top();
        pq.pop();
        int val = node.first.first;
        if(val * (-1) >= mn_price){
            break;
        }
        int idx = node.second.first;
        int r = node.second.second.first;
        int cat_remain = node.second.second.second;

        if(r == 0){
            mn_price = val * (-1);
        }else if(cat_remain >= r && idx<s){
            pq.push(make_pair(make_pair(val, node.first.second), make_pair(idx + 1,make_pair(r,cat_remain - catalog[idx].size()))));
            int bc = 0;
            for(int book:catalog[idx]){
                if(node.first.second[book] == 0){
                    bc++;
                    node.first.second[book] = 1;
                }
            }
            if(bc > 0){
                pq.push(make_pair(make_pair(val - cost[idx], node.first.second), make_pair(idx + 1,make_pair(r - bc,cat_remain - catalog[idx].size()))));
            }
        }
    }
    cout << mn_price;
}
