#include <iostream>

using namespace std;

int main()
{
    int time,mFront,mSize,mCap,last,collection;
    cin>>time;
    while(time!=0){
        cin>>mFront>>mSize>>mCap>>last>>collection;
        time--;
        if (collection==0){
            if(last!=(mFront+mSize)% mCap){
                cout<<"WRONG"<<"\n";
                continue;
            }
            if(mCap<=mSize){
                cout<<"WRONG"<<"\n";
                continue;
            }
            if(mFront>=mCap){
                cout<<"WRONG"<<"\n";
                continue;
            }

        }
        else if(collection==1){
            if (last<mFront){
                if(mSize!=(mCap+last-mFront)% mCap){
                    cout<<"1WRONG "<<(mSize+last-mCap)% mCap<<"\n";
                    continue;
            }
            else{
                if (mSize!=last-mFront){
                    cout<<"2WRONG "<<last-mSize<<"\n";
                    continue;
                }
            }
        }
        else if(collection==2){
            if (last<mFront){
                if(mSize!=(mCap-last+mFront)% mCap){
                    cout<<"WRONG "<<mCap-last+mFront<<"\n";
                    continue;;
                }
            }
            else{
                if (mSize!=last-mFront){
                    cout<<"WRONG "<<last-mFront<<"\n";
                    continue;;
                }
            }
            if(mCap<mSize){
                cout<<"WRONG "<<mCap<<"\n";
                continue;;
            }
        }else if(collection==3){
            if (mCap<mSize || mCap<last){
                if(mSize>last){
                    cout<<"WRONG "<<mSize<<"\n";
                    continue;}
                else{
                    cout<<"WRONG "<<last+1<<"\n";
                    continue;
                }
            }
        }
        else{
            if (last<mFront){
                if(mSize!=(mCap-last+mFront)% mCap){
                    cout<<"WRONG "<<mCap-mSize+mFront<<"\n";
                    continue;
                }
            }
            else{
                if (mSize!=last-mFront){
                    cout<<"WRONG "<<mFront+mSize<<"\n";
                    continue;
                }
            }
        }
        cout<<"OK"<<"\n";}

    return 0;
}
}
