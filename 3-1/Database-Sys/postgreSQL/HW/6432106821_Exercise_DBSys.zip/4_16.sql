UPDATE product
SET standard_price = 5400
WHERE product_id = 5;

SELECT * FROM product;