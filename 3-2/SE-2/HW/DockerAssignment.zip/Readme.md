Open terminal of db container then enter command

```
mysql -u root -p -h localhost
```

password is `thisismyverysecurepassword55555`

Then enter the following commands

```
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '123';

ALTER USER 'users_service' IDENTIFIED WITH mysql_native_password BY '123';

flush privileges;
```

Open other terminal and enter the following commands to check if everything is working

```
curl -L http://localhost/?username=alice | json_pp
```

sometimes this command will return empty profile_image because bug in asset_service (asynchronous), try again after a few seconds
